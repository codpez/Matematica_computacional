from criba import criba_eratostenes
import sys
import math

def factorizacion_prima(primos,numero):
    factorizacion_prima=[]
    temp=0
    for numeroPrimo in primos:

        if numero % numeroPrimo == 0:
            factorizacion_prima.append(numeroPrimo)
        else:
            continue



if __name__ == '__main__':
    numero = int(sys.argv[1])

    raiz_numero = math.sqrt(numero)

    listaDePrimos = criba_eratostenes(raiz_numero)

